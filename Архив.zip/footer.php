<link rel="stylesheet" href="css/footer.css">
<footer class="footer">
    <div class="footer__column">
        <img  style="width: fit-content; height: 40px;; "src="img/logo.svg">
    </div>

    <div class="footer__column">
        <p class="footer__text">О проекте</p>
    </div>

    <div class="footer__column">
        <p class="footer__text">Политика конфидициальности</p>
    </div>

    <div class="footer__column">
        <p class="footer__text">Контакты</p>
    </div>
</footer>

